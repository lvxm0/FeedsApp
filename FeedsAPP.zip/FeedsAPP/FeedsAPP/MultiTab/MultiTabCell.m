//
//  MultiTabCell.m
//  FeedsAPP
//
//  Created by Yueyue on 2019/5/11.
//  Copyright © 2019 iosGroup. All rights reserved.
//

#import "MultiTabCell.h"

@interface MultiTabCell()

@end

@implementation MultiTabCell

@end
